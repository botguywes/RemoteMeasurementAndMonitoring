<!DOCTYPE html>
<html>
  <head>
    <title>RPi Cam Preview</title>
    <script src="script_min.js"></script>
  </head>
  <body onload="setTimeout('init();', 100);">
    <center>
      <div><img id="mjpeg_dest" /></div>
    </center>
  </body>
</html>
