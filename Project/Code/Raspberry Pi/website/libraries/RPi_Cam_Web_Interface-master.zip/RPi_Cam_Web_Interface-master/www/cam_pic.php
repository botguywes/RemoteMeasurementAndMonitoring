<?php

  header("Content-Type: image/jpeg");
  readfile("/dev/shm/mjpeg/cam.jpg");

?>
